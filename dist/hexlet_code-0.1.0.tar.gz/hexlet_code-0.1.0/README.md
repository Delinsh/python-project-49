### Hexlet tests and linter status:
[![Actions Status](https://github.com/Delinsh/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Delinsh/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/54216723e31d7536b5a8/maintainability)](https://codeclimate.com/github/Delinsh/python-project-49/maintainability)